
# Main file for the team project

def main():
    print("Welcome to the Team Project!")

if __name__ == "__main__":
    main()
