
# Contributing Guidelines

We welcome contributions to this project. Please follow these steps:

1. Fork the repository.
2. Create a new branch for your feature or bugfix: `git checkout -b feature-name`.
3. Make your changes and commit them: `git commit -m "Description of changes"`.
4. Push your branch to GitHub: `git push origin feature-name`.
5. Submit a pull request to the `main` branch.

## Code of Conduct
- Be respectful to all contributors.
- Write clear and concise commit messages.
- Ensure your code follows the project's style guidelines.
